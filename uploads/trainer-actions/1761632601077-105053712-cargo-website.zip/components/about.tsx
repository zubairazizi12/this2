import { CheckCircle2 } from "lucide-react"

const stats = [
  { value: "25+", label: "Years Experience" },
  { value: "150+", label: "Countries Served" },
  { value: "50K+", label: "Shipments Annually" },
  { value: "98%", label: "On-Time Delivery" },
]

const features = [
  "Real-time shipment tracking",
  "Dedicated account managers",
  "24/7 customer support",
  "Competitive pricing",
  "Insurance coverage",
  "Sustainable practices",
]

export function About() {
  return (
    <section id="about" className="py-20 lg:py-32 bg-muted/30">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left Column - Image */}
          <div className="relative">
            <div className="aspect-[4/3] rounded-lg overflow-hidden">
              <img src="/modern-cargo-warehouse-with-workers.jpg" alt="About GlobalCargo" className="w-full h-full object-cover" />
            </div>
            <div className="absolute -bottom-6 -right-6 bg-primary text-primary-foreground p-8 rounded-lg shadow-xl hidden md:block">
              <div className="text-4xl font-bold">25+</div>
              <div className="text-sm">Years of Excellence</div>
            </div>
          </div>

          {/* Right Column - Content */}
          <div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 text-balance">
              Leading the Way in Global Logistics
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              Since 1999, GlobalCargo has been at the forefront of international shipping and logistics. We combine
              cutting-edge technology with decades of expertise to deliver exceptional service.
            </p>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Our commitment to reliability, efficiency, and customer satisfaction has made us a trusted partner for
              businesses of all sizes across the globe.
            </p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-6 mb-8">
              {stats.map((stat, index) => (
                <div key={index}>
                  <div className="text-3xl lg:text-4xl font-bold text-primary mb-1">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-foreground">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
