import { Card, CardContent } from "@/components/ui/card"
import { Ship, Plane, Truck, Package, Globe, Clock } from "lucide-react"

const services = [
  {
    icon: Ship,
    title: "Ocean Freight",
    description: "Cost-effective sea transportation for large shipments with full container and LCL options.",
  },
  {
    icon: Plane,
    title: "Air Freight",
    description: "Fast and reliable air cargo services for time-sensitive deliveries worldwide.",
  },
  {
    icon: Truck,
    title: "Ground Transport",
    description: "Comprehensive road freight solutions with door-to-door delivery services.",
  },
  {
    icon: Package,
    title: "Warehousing",
    description: "Secure storage facilities with inventory management and distribution services.",
  },
  {
    icon: Globe,
    title: "Customs Clearance",
    description: "Expert customs brokerage to ensure smooth international trade compliance.",
  },
  {
    icon: Clock,
    title: "Express Delivery",
    description: "Urgent shipment solutions with guaranteed delivery times and real-time tracking.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-20 lg:py-32 bg-background">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">Our Services</h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-pretty">
            Comprehensive logistics solutions tailored to meet your business needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8">
          {services.map((service, index) => {
            const Icon = service.icon
            return (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardContent className="p-6 lg:p-8">
                  <div className="mb-4 inline-flex p-3 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="text-xl lg:text-2xl font-bold text-foreground mb-3">{service.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
